'use strict'

// Asenna ensin mysql driver 
// npm install mysql --save

var mysql = require('mysql');

var connection = mysql.createConnection({
  host     : 'localhost',   // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  user     : 'testi',       // HUOM!! tsekkaa että databasen tiedot täsmäävät omaasi! !!
  password : 'testitesti!', //                                                        !!
  database : 'testi'        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
});

module.exports = 
{
    fetchTypes: function (req, res) {
      connection.query('SELECT Avain, Lyhenne, Selite FROM asiakastyyppi', function(error, results, fields){
        if ( error ){
          console.log("Virhe haettaessa dataa Asiakas-taulusta, syy: " + error);
          //res.send(error);
          //res.send(JSON.stringify({"status": 500, "error": error, "response": null})); 
          res.send({"status": 500, "error": error, "response": null}); 
        }
        else
        {
          console.log("Data = " + JSON.stringify(results));
          res.json(results);
        }
    });

    },

    createType: function(req, res){
      var avain = req.query.avain;
      var lyhenne = req.query.lyhenne;
      var selite = req.query.selite;

      if (typeof avain != 'undefined' && typeof lyhenne != 'undefined' && typeof selite != 'undefined')
      {
        connection.query('INSERT INTO asiakastyyppi (AVAIN, LYHENNE, SELITE) VALUES ("' + avain + '", "'+ lyhenne + '", "'+ selite +'")', function(error, results, fields){
          if ( error ){
            console.log("Virhe lisätessä asiakastyyppiä, syy: " + error);
            res.send({"status": 500, "error": error, "response": null}); 
          }
          else
          {
            console.log("CREATE OK.");
            res.send({"status": 200});
          }
  
        });
      }
      else
      {
        res.send("Vajaavaiset tiedot. Ei voitu lisätä.");
      }
      
    },

    updateType: function(req, res){
      var avain = req.params.id;
      var lyhenne = req.query.lyhenne;
      var selite = req.query.selite;

      connection.query('UPDATE asiakastyyppi SET LYHENNE = "'+ lyhenne +'", SELITE = "' + selite +'" WHERE AVAIN="' + avain + '"', function(error, results, fields){
        if ( error ){
          console.log("Virhe päivitettäessä asiakastyyppiä, syy: " + error);
          res.send({"status": 500, "error": error, "response": null});
        }
        else
        {
          console.log("UPDATE OK.");
          res.send({"status": 200});
        }

      });
    },

    deleteType : function (req, res) {
      var avain = req.params.id;

      if (typeof avain != 'undefined')
      {
        connection.query('DELETE FROM asiakastyyppi WHERE avain="'+ avain +'"', function(error, results, fields){
          if ( error ){
            console.log("Virhe poistettaessa asiakastyyppiä, syy: " + error);
            res.send({"status": 500, "error": error, "response": null}); 
          }
          else
          {
            console.log("DELETE OK.");
            res.send({"status": 200});
          }
  
        });
      }
    },

    fetchAll: function(req, res){
      var nimi = req.query.nimi;
      var osoite = req.query.osoite;
      var asiakastyyppi = req.query.asty_avain;

      console.log("Asiakastyyppi: " + asiakastyyppi);

      var haku = 'SELECT * FROM asiakas WHERE 1=1';

      if (typeof nimi != 'undefined')
        haku = haku + ' AND NIMI LIKE "%'+ nimi + '%"';
           
      if ((typeof asiakastyyppi != 'undefined') && asiakastyyppi != "Ei valintaa")
        haku =  haku + ' AND ASTY_AVAIN="'+ asiakastyyppi + '"';

      if(typeof osoite != 'undefined')
        haku = haku + ' AND OSOITE LIKE "%'+ osoite + '%"';
      
      connection.query(haku, function(error, results, fields){
        if ( error ){
          console.log("Virhe haettaessa dataa Asiakas-taulusta, syy: " + error);
          //res.send(error);
          //res.send(JSON.stringify({"status": 500, "error": error, "response": null})); 
          res.send({"status": 500, "error": error, "response": null}); 
        }
        else
        {
          console.log("Data = " + JSON.stringify(results));
          res.json(results);
          console.log("nimi: " + nimi);
         
        }
        console.log("Params = " + JSON.stringify(req.query));

      });

    },

    create: function(req, res){
      
      var nimi = req.body.nimi;
      var osoite = req.body.osoite;
      var asiakastyyppi = req.body.asty_avain;
      var postitoimipaikka = req.body.postitmp;
      var postinumero = req.body.postinro;
      var luontipvm = new Date();

      console.log("LISÄYS");
      console.log("NIMI: " + nimi);

      if (typeof nimi != 'undefined' && typeof osoite != 'undefined' && typeof asiakastyyppi != 'undefined' && typeof postitoimipaikka != 'undefined' && typeof postinumero != 'undefined')
      {
        connection.query('INSERT INTO asiakas (NIMI, OSOITE, POSTINRO, POSTITMP, LUONTIPVM, ASTY_AVAIN) VALUES ("' + nimi + '", "'+ osoite + '", "'+ postinumero +'", "'+ postitoimipaikka +'", "'+ luontipvm +'", "' + asiakastyyppi + '")', function(error, results, fields){
          if ( error ){
            console.log("Virhe lisätessä asiakasta, syy: " + error);
            res.send({"status": 500, "error": error, "response": null}); 
          }
          else
          {
            console.log("CREATE OK.");
            res.send({"status": 200});
          }
  
        });
      }
      else
      {
        res.send("Vajaavaiset tiedot. Ei voitu lisätä.");
      }
      
    },

    update: function(req, res){
      var nimi = req.query.nimi;
      var osoite = req.query.osoite;
      var asiakastyyppi = req.query.asty_avain;
      var postitoimipaikka = req.query.postitmp;
      var postinumero = req.query.postinro;
      var avain = req.params.id;

      connection.query('UPDATE asiakas SET NIMI = "'+ nimi +'", OSOITE = "' + osoite +'", POSTINRO = "' + postinumero + '", POSTITMP = "' + postitoimipaikka + '", ASTY_AVAIN = " ' + asiakastyyppi + '" WHERE avain = "' + avain + '"', function(error, results, fields){
        if ( error ){
          console.log("Virhe päivitettäessä asiakasta, syy: " + error);
          res.send({"status": 500, "error": error, "response": null}); 
        }
        else
        {
          console.log("UPDATE OK.");
          res.send({"status": 200});
        }

      });
    },

    delete : function (req, res) {
      var avain = req.body.avain;

      if (typeof avain != 'undefined')
      {
        connection.query('DELETE FROM asiakas WHERE avain="'+ avain +'"', function(error, results, fields){
          if ( error ){
            console.log("Virhe poistettaessa asiakasta, syy: " + error);
            res.send({"status": 500, "error": error, "response": null}); 
          }
          else
          {
            console.log("DELETE OK.");
            res.send({"status": 200});
          }
  
        });
      }
    }
}
