// Täällä löytyy routet

const express = require('express')
const router = express.Router()
const mysql = require('mysql')
//bodyParser parsaa queryt -- asenna npm i body-parser
const bodyParser = require('body-parser')
router.use(bodyParser.urlencoded({extended: false}))
//Overridetaan html rajoitteita -- asenna npm i method-override
const methodOverride = require('method-override');

router.use(express.static('./public'))
function getConnection(){
  return mysql.createConnection({
      host     : 'localhost',
      user     : 'root',  // HUOM! Älä käytä root:n tunnusta tuotantokoneella!!!!
      password : '',
      database : 'customer'
  })
}


router.get('/messages', (req, res) =>{

  console.log("Tämä on testiviesti..")
  res.end()

})

module.exports = router



router.post('/user_create', (req, res) => {
  console.log("Luodaan uusi käyttäjä...")

  const nimi = req.body.create_nimi
  const osoite = req.body.create_osoite
  const postinro = req.body.create_postinro
  const postitmp = req.body.create_postitmp
  const luontipvm = req.body.create_luontipvm
  const asty_Avain = req.body.create_asty_Avain
  var array = [nimi, osoite, postinro, postitmp, luontipvm, asty_Avain]
  //Tarkistetaan onko tyhjiä kenttiä
  array.forEach(function(element){
    if(element == '' ){
      throw "Jotkin tiedot puuttuvat"
    }
    console.log(element);
  });
  

  const queryString = "INSERT INTO asiakas (nimi, osoite, postinro, postitmp, luontipvm, asty_Avain) VALUES(?, ?, ?, ?, ?, ?)"
  getConnection().query(queryString, [nimi, osoite, postinro, postitmp, luontipvm, asty_Avain], (err, results, fields) => {

      if ( err ){
          console.log("Virhe viedessä dataa Asiakas-tauluun, syy: " + err);
          res.send({"Jokin meni pieleen! status": 500, "error": err, "response": null}); 
          return
      }
      else {
      
      console.log("Viety tiedot:", results);
      res.send('Tiedot lisätty onnistuneesti ' + nimi)
      res.end()
      }


  })
 
})
//Overridetaan jotta voidaan käyttää deleteä htmlssä
router.use(methodOverride('_method'));

router.delete('/user_delete',  (req, res) => {
  console.log("Poistetaan käyttäjä...")
  const nimi = req.body.delete_nimi
  const queryString = "DELETE FROM asiakas WHERE nimi= ? "
  getConnection().query(queryString, nimi, (err, results, fields) => {

      if ( err ){
          console.log("Virhe poistaessa tietoa, syy: " + err);
          res.send({"Jokin meni pieleen! status": 500, "error": err, "response": null}); 
          return
      }
      else {
      
      console.log("Tiedot poistettu:", results);
      res.send('Tiedot poistettu onnistuneesti: ' + nimi)
      res.end()
      }

  })
 
})