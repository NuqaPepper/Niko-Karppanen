const express = require('express')
const app = express()
//Morgan loggaaja -asenna npm i morgan
const morgan = require('morgan')

const bodyParser = require('body-parser')

//Keksi sessiot --asenna npm i express-session
const session = require('express-session')
const router = require('./customerController.js')
//Keksin elinikä
const ONE_HOUR = 1000 * 60 * 60
let date_ob = new Date();
let hours = date_ob.getHours()
let minutes = date_ob.getMinutes()
const redirectLogin = (req, res, next) => {
    if (!req.session.userId) {
        res.redirect('/login')

    } else{
        next()
    }
}
const redirectHome = (req, res, next) => {
    if (req.session.userId) {
        res.redirect('/home')

    } 
}

const users = [
    {id: 1, name: 'Seppo', password: 'secret'},
    {id: 2, name: 'Matti', password: 'secret'},
    {id: 3, name: 'Kerttu', password: 'secret'},
    
]
const {
    NODE_ENV = 'development',
    SESS_LIFETIME = ONE_HOUR,
    SESS_NAME = 'sid',
    SESS_SECRET = 'salasana'

} = process.env
const IN_PROD = NODE_ENV === 'production'
//Käytetään cookie sessiota, määritellään asetukset:
app.use(session({
    name: SESS_NAME,
    saveUninitialized: false,
    secret: SESS_SECRET,
    resave: false,
    cookie: {
        maxAge: SESS_LIFETIME,
        sameSite: true,
        secure: IN_PROD
   
    }
}))

app.use(bodyParser.urlencoded({
    extended: true
}))


// Rootti sivu
app.get('/', (req, res) => {
    const { userId } = req.session
    console.log(userId)
    res.send(`<h1>Tervetuloa</h1>
    ${userId ? `
    <a href='/home'>Kotiin</a>
    <form method='POST' action='/logout'>
    <button>Kirjaudu ulos</button>
    </form>
    ` : `
    <a href='/login'>Kirjaudu sisään</a>
    `}
    
    `)
})
//Kotisivu, jos käyttäjä ei kirjautunut, heitetään takaisin Login sivulle
app.get('/home', redirectLogin, (req, res) => {
    const user = users.find(user => user.id === req.session.userId)
    res.send(`
    <h1>Koti</h1>
    <a href='/'>Takaisin</a><br>
    <a href='/index.html'>Lisää / Poista käyttäjiä</a>
    <h2> Käyttäjän tiedot </h2>
    <ul>
        <li>Nimi: ${user.name} </li>
        <li>Kirjauduttu: ${hours}:${minutes} </li>
        <li>ID: ${SESS_NAME} </li>
    </ul>
    <form method='POST' action='/logout'>
    <input type='submit' value='Kirjaudu ulos' />
    </form>
    `)
})
//Kirjautumissivu
app.get('/login', (req, res) => {
    console.log(req.session) 
    
    res.send(`
    <h1>Kirjaudu</h1><br>
    <p>Testaajalle! <br> Nimi: Seppo <br> Salasana: secret</p>
    <form method='POST' action='/login'>
        <input type='name' name='name' placeholder='Nimi' required />
        <input type='password' name='password' placeholder='Salasana' required /> 
        <input type='submit' /> 
    </form>

    `)
})
app.post('/login', (req, res) => {

    const { name, password } = req.body
    
    if(name && password) {
        const user = users.find(
            user => user.name === name && user.password === password
            )
        if (user) {
            req.session.userId = user.id
            
            return res.redirect('/home')
        }
    }
    
    res.redirect('/login')

})
// Tuhoaa cookien uloskirjauksen yhteydessä
app.post('/logout', redirectLogin, (req, res) => {
    console.log("Kirjauduttu ulos")
    req.session.destroy(err => {
        if(err){
            return res.redirect('/home')
        }
        res.clearCookie(SESS_NAME)
        res.redirect('/login')
    })
})


app.use(router)
app.use(morgan('short'))

//localhost:3003
app.listen(3003, () => {
    console.log("Servu päällä 3003... http://localhost:3003/home")
})
